package model;

/**
 * Kelas abstrak untuk perhitungan BMI (Body Mass Index).
 * Rumus BMI sama untuk semua standar, tetapi cara menentukan
 * kategorinya berbeda -> diserahkan ke subclass (polimorfisme).
 */
public abstract class Bmi {

    private final String nama;
    private final double beratKg;
    private final double tinggiCm;

    public Bmi(String nama, double beratKg, double tinggiCm) {
        if (nama == null || nama.isBlank()) {
            throw new IllegalArgumentException("Nama wajib diisi.");
        }
        if (beratKg < 1 || beratKg > 500) {
            throw new IllegalArgumentException("Berat badan harus antara 1 - 500 kg.");
        }
        if (tinggiCm < 50 || tinggiCm > 300) {
            throw new IllegalArgumentException("Tinggi badan harus antara 50 - 300 cm.");
        }

        this.nama = nama.trim();
        this.beratKg = beratKg;
        this.tinggiCm = tinggiCm;
    }

    public String getNama() {
        return nama;
    }

    public double getBeratKg() {
        return beratKg;
    }

    public double getTinggiCm() {
        return tinggiCm;
    }

    /** BMI = berat (kg) / (tinggi (m) x tinggi (m)) */
    public double hitungBmi() {
        double tinggiM = tinggiCm / 100.0;
        return beratKg / (tinggiM * tinggiM);
    }

    public abstract String getKategori();

    public abstract String getStandar();
}
