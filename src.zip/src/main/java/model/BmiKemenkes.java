package model;

public class BmiKemenkes extends Bmi {

    public BmiKemenkes(String nama, double beratKg, double tinggiCm) {
        super(nama, beratKg, tinggiCm);
    }

    @Override
    public String getKategori() {
        double bmi = hitungBmi();
        if (bmi < 18.5) {
            return "Kurus";
        } else if (bmi <= 25.0) {
            return "Normal";
        } else if (bmi <= 27.0) {
            return "Gemuk (kelebihan berat badan)";
        } else {
            return "Obesitas";
        }
    }

    @Override
    public String getStandar() {
        return "Kemenkes RI";
    }
}
