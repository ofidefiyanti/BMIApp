package model;

public class BmiWho extends Bmi {

    public BmiWho(String nama, double beratKg, double tinggiCm) {
        super(nama, beratKg, tinggiCm);
    }

    @Override
    public String getKategori() {
        double bmi = hitungBmi();
        if (bmi < 18.5) {
            return "Berat badan kurang";
        } else if (bmi < 25.0) {
            return "Normal";
        } else if (bmi < 30.0) {
            return "Berat badan berlebih";
        } else {
            return "Obesitas";
        }
    }

    @Override
    public String getStandar() {
        return "WHO";
    }
}
