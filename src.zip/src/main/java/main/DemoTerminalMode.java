package main;

import model.Bmi;
import model.BmiKemenkes;
import model.BmiWho;

public class DemoTerminalMode {
    public static void main(String[] args) {
        Bmi a = new BmiWho("Rani", 60, 165);
        System.out.printf("%s | BMI %.1f | %s (%s)%n",
            a.getNama(), a.hitungBmi(), a.getKategori(), a.getStandar());

        Bmi b = new BmiKemenkes("Budi", 80, 170);
        System.out.printf("%s | BMI %.1f | %s (%s)%n",
            b.getNama(), b.hitungBmi(), b.getKategori(), b.getStandar());

        Bmi c = new BmiWho("Budi", 80, 170);
        System.out.printf("%s | BMI %.1f | %s (%s)%n",
            c.getNama(), c.hitungBmi(), c.getKategori(), c.getStandar());
    }
}
