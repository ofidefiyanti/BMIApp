package controller;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Bmi;
import model.BmiKemenkes;
import model.BmiWho;

public class BmiController {
    @FXML private TextField namaField;
    @FXML private TextField beratField;
    @FXML private TextField tinggiField;
    @FXML private ComboBox<String> standarBox;
    @FXML private Label hasilLabel;

    private static final String PESAN_AWAL = "Hasil perhitungan akan tampil di sini.";

    @FXML
    private void initialize() {
        standarBox.getItems().addAll("WHO", "Kemenkes RI");
        standarBox.setValue("WHO");
    }

    @FXML
    private void hitung() {
        try {
            double berat = parseAngka(beratField.getText());
            double tinggi = parseAngka(tinggiField.getText());

            Bmi bmi;
            if ("Kemenkes RI".equals(standarBox.getValue())) {
                bmi = new BmiKemenkes(namaField.getText(), berat, tinggi);
            } else {
                bmi = new BmiWho(namaField.getText(), berat, tinggi);
            }

            hasilLabel.setStyle("-fx-text-fill: " + warnaKategori(bmi.getKategori()) + ";");
            hasilLabel.setText("Nama: " + bmi.getNama()
                + "\nBMI: " + String.format("%.1f", bmi.hitungBmi())
                + "\nKategori: " + bmi.getKategori()
                + "\nStandar: " + bmi.getStandar());
        } catch (NumberFormatException e) {
            tampilkanError("Berat dan tinggi harus berupa angka (contoh: 60 atau 60,5).");
        } catch (IllegalArgumentException e) {
            tampilkanError(e.getMessage());
        }
    }

    @FXML
    private void reset() {
        namaField.clear();
        beratField.clear();
        tinggiField.clear();
        standarBox.setValue("WHO");
        hasilLabel.setStyle("-fx-text-fill: #0f172a;");
        hasilLabel.setText(PESAN_AWAL);
    }

    private double parseAngka(String teks) {
        return Double.parseDouble(teks.trim().replace(',', '.'));
    }

    private String warnaKategori(String kategori) {
        if (kategori.startsWith("Normal")) {
            return "#166534";   // hijau
        } else if (kategori.startsWith("Obesitas")) {
            return "#b91c1c";   // merah
        }
        return "#b45309";       // oranye
    }

    private void tampilkanError(String pesan) {
        hasilLabel.setStyle("-fx-text-fill: #b91c1c;");
        hasilLabel.setText(pesan);
    }
}
